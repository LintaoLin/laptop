# -*- coding: utf-8 -*-

# intellij idea 脚本开发思路

# 1. 查看是否有对应的应用软件
# jetbrainsAppPath: /Applications/IntelliJ IDEA.app
# jetbrainsAppConfigPath: /Users/lint/Library/Application Support/JetBrains/IntelliJIdea2020.3

# 2. 查看应用library /Users/lint/Library/Application Support/JetBrains/IntelliJIdea2020.3/options/recentProjects.xml
# 3. 解析xml

# 4. os.environ['open_twice']，通过 os.environ 拿到在alfred配置的环境变量

import os
import json
import xml.etree.cElementTree as ElementTree
import sys

# get HOME environment value os.environ['HOME']

IDEA_KEY = "IDEA"
PYCHARM_KEY = "PYCHARM"
GOLAND_KEY = "GoLand"
CLION_KEY = "CLion"

app_path_map = {
    IDEA_KEY: "/Applications/IntelliJ IDEA.app",
    PYCHARM_KEY: "/Applications/PyCharm.app",
    GOLAND_KEY: "/Applications/GoLand.app",
    CLION_KEY: "/Applications/CLion.app"
}

intellij_local_bin_map = {
    IDEA_KEY: '/usr/local/bin/idea',
    PYCHARM_KEY: "/usr/local/bin/charm",
    GOLAND_KEY: "/usr/local/bin/goland",
    CLION_KEY: "/usr/local/bin/clion"
}

app_full_name_map = {
    IDEA_KEY: "IntelliJ IDEA",
    PYCHARM_KEY: "PyCharm",
    GOLAND_KEY: "GoLand",
    CLION_KEY: "CLion"
}


class Project(object):
    project_name = None
    project_path = None

    def __init__(self):
        pass


class ProductInfo(object):
    name = None
    version = None
    buildNumber = None
    productCode = None
    customProperties = None
    dataDirectoryName = None


debug_mode = os.environ['debug_mode'] == '1'
debug_infos = {}


def search_project(args):
    app_name = args[0]

    projects = search_app(app_name)

    debug_infos['args'] = args

    result = {}

    if len(args) > 1:
        result_items = []
        if projects:
            for proj in projects:
                if args[1].lower() in proj.project_name.lower():
                    result_items.append(build_project_item(proj, app_name))
        result["items"] = result_items
    else:
        result_items = []
        if projects:
            for proj in projects:
                result_items.append(build_project_item(proj, app_name))
        result["items"] = result_items
    if debug_mode:
        result['debug_infos'] = debug_infos
    return result


def search_app(app_name):
    app_path = app_path_map.get(app_name)
    if not app_path:
        debug_infos["error"] = "app_name:{} not find in app_path_map".format(app_name)
        return []
    product_info_path = os.path.join(app_path, 'Contents/Resources/product-info.json')
    with open(product_info_path) as product_info_json:
        json_result = json.load(product_info_json)
        # print("json_result:{}".format(json_result))
        data_directory_name = json_result['dataDirectoryName']
        # print("dataDirectoryName: {}".format(data_directory_name))

    if data_directory_name:
        jetbrains_library_path = '/Users/lint/Library/Application Support/JetBrains/'
        app_library_path = os.path.join(jetbrains_library_path, data_directory_name)

    debug_infos['app_library_path'] =  app_library_path

    projects = list_project(app_library_path)
    debug_infos['project_size'] = len(projects)
    return projects


def build_project_item(project, app_name):
    local_bin = intellij_local_bin_map.get(app_name)
    arg = u"{} {}".format(local_bin, project.project_path)
    # if os.environ['open_twice'] == '1':
    #     arg = "{} {}".format(idea_local_bin, arg)
    args = {
        "arg": arg,
        "app_name": app_full_name_map.get(app_name)
    }
    return {
        "uid": project.project_name,
        "title": project.project_name,
        "subtitle": project.project_path,
        "arg": json.dumps(args),
        "autocomplete": project.project_name,
        "text": {
            "copy": project.project_path,
            "largetype": project.project_path
        },
        "icon": {
            "type": "fileicon",
            "path": app_path_map.get(app_name)
        }
    }


def list_project(app_library_path):
    recent_file_path = os.path.join(app_library_path, 'options/recentProjects.xml')
    tree = ElementTree.ElementTree(file=recent_file_path)

    debug_infos['recent_file_path'] = recent_file_path

    projects = []
    root = tree.getroot()
    home_path = os.environ['HOME']
    for elem in root.iter('entry'):
        project_path = elem.attrib.get("key").replace("$USER_HOME$", home_path)
        value = elem.find("value")
        if not value:
            continue
        meta_info = value.find("RecentProjectMetaInfo")
        project_name = project_path.split('/')[-1]
        if meta_info:
            prj = Project()
            prj.project_path = project_path
            if meta_info.attrib.get("frameTitle"):
                project_name = meta_info.attrib.get("frameTitle").split(u" – ")[0]
            prj.project_name = project_name
            projects.append(prj)

    # print([project.project_path for project in projects])
    return projects


if __name__ == "__main__":
    result = search_project(sys.argv[1:])
    if result:
        json.dump(result, sys.stdout)
