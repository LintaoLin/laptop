## requirement

```
brew install gobject-introspection
brew install cario
sudo pip install -U PyObjC
sudo pip install pycairo
brew install pkg-config
pip install AppKit
```
